document.addEventListener('DOMContentLoaded',()=>{
 const toggle=document.querySelector('.menu-toggle'),nav=document.querySelector('.nav-links');
 if(toggle&&nav) toggle.addEventListener('click',()=>{const open=nav.classList.toggle('open');toggle.setAttribute('aria-expanded',String(open));});
 const search=document.querySelector('#productSearch'),cards=document.querySelectorAll('.product-card');
 if(search&&cards.length) search.addEventListener('input',()=>{const q=search.value.toLowerCase().trim();cards.forEach(c=>c.hidden=q!==''&&!c.textContent.toLowerCase().includes(q));});
 document.querySelectorAll('form[data-form]').forEach(form=>form.addEventListener('submit',e=>{e.preventDefault();if(!form.checkValidity()){form.reportValidity();return}const msg=form.querySelector('.form-message');if(msg)msg.textContent='Thank you. Your information has been received.';}));
});
