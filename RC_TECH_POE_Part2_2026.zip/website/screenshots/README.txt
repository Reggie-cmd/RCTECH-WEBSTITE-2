SCREENSHOT EVIDENCE

Replace this file with actual screenshots before submission.

Required files:
desktop.png
tablet.png
mobile.png

Use Chrome Developer Tools/device emulation and capture the RC TECH website at different viewport sizes.
