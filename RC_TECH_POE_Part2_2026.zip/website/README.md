# RC TECH — Web Development POE Part 2

## Project
RC TECH is an electronics and technology accessories website developed from the Part 1 foundation. Part 2 focuses on CSS styling, desktop layout, responsive design and documenting improvements made after Part 1.

## Pages
- `index.html` — Home
- `about.html` — About
- `products.html` — Products
- `enquiry.html` — Product enquiry
- `contact.html` — Contact

## 2. CSS Styling for Desktop Solution

### External stylesheet
All five HTML pages link to the shared `css/style.css` stylesheet. A CSS reset is included using the universal selector so browser default margins and padding do not create inconsistent spacing.

### Base and typography styles
The stylesheet establishes a common font family, base font size, line height, colour palette, headings and paragraph styling. CSS custom properties are used for the RC TECH blue, navy, white, borders, radius and shadows so repeated values can be changed centrally.

### Layout structure
CSS Grid and Flexbox are used throughout the desktop solution:
- Home hero: two-column CSS Grid.
- Product catalogue: three-column CSS Grid on large screens.
- About content: two-column Grid.
- Navigation: Flexbox.
- Buttons: Flexbox alignment.

### Visual styling
The website uses RC TECH blue, navy, white and light-blue backgrounds. Cards use borders, rounded corners and shadows. Navigation links, buttons and cards have `:hover` and `:focus-visible` states. The active navigation page is indicated by colour and an underline.

## 3. Responsive Design

### Breakpoints
- Desktop: above 56rem.
- Tablet: 42rem–56rem.
- Mobile: below 42rem.
- Small mobile: below 24rem.

At tablet width, the hero changes from two columns to one and the product grid changes from three columns to two. At mobile width, the product grid becomes one column, buttons become full width and the navigation changes into a collapsible menu.

### Relative units
The CSS uses `rem`, percentages and `clamp()` for scalable sizing. The main container uses a percentage width with a maximum width. This prevents content from becoming too wide on large screens while retaining usable margins on smaller screens.

### Responsive images
All RC TECH illustrations use SVG files and CSS rules including `max-width: 100%` and `height: auto`. Product cards use `aspect-ratio` so images remain contained within consistent card areas without overflowing.

### Testing and iteration
The website should be tested with Chrome Developer Tools using desktop, tablet and mobile viewport sizes. Actual evidence screenshots must be captured by the student and placed in the `screenshots` folder. These screenshots should show the responsive layout at different screen sizes.

## Part 1 Feedback / Corrections

The Part 1 foundation was reviewed before the Part 2 redesign. The following improvements were implemented:
1. Standardised all five pages around one external stylesheet.
2. Improved consistency of typography, spacing and colour usage.
3. Added a structured desktop Grid/Flexbox layout.
4. Added consistent button, card and form styling.
5. Added navigation hover, focus and active states.
6. Added responsive breakpoints for tablet and mobile.
7. Replaced fixed-style layout behaviour with relative sizing.
8. Added responsive image rules.
9. Added a collapsible mobile navigation menu.

## Changelog

### Version 2.0 — Part 2 CSS and Responsive Design
- `index.html`: linked the page to `css/style.css`, added a responsive two-column hero and improved button styling.
- `about.html`: linked the external stylesheet and applied the responsive two-column mission/vision layout.
- `products.html`: applied a three-column desktop CSS Grid, two-column tablet layout and one-column mobile layout. Product images were made responsive.
- `enquiry.html`: applied consistent form layout, labels, inputs, buttons, borders and focus states.
- `contact.html`: applied the same responsive form system and consistent page spacing.
- `css/style.css`: added CSS reset, base styles, typography, CSS variables, Grid, Flexbox, visual styling, pseudo-classes, responsive breakpoints and responsive image rules.
- `js/script.js`: added the mobile navigation toggle and retained product-search/form interaction support.
- Added desktop, tablet and mobile testing requirements to the README.

## Screenshot Evidence

Before submission, add your own screenshots:
- `screenshots/desktop.png` — desktop viewport.
- `screenshots/tablet.png` — tablet viewport.
- `screenshots/mobile.png` — mobile viewport.

Suggested evidence captions:
- **Desktop:** full navigation, two-column hero and multi-column product layout.
- **Tablet:** reduced columns and adjusted spacing.
- **Mobile:** single-column content, full-width buttons and collapsed navigation.

## Testing Checklist
- [ ] All five pages open correctly.
- [ ] All navigation links work.
- [ ] Desktop layout tested.
- [ ] Tablet layout tested.
- [ ] Mobile layout tested.
- [ ] Mobile menu tested.
- [ ] Product search tested.
- [ ] Enquiry form validation tested.
- [ ] Contact form validation tested.
- [ ] Images do not overflow their containers.
- [ ] Desktop screenshot added.
- [ ] Tablet screenshot added.
- [ ] Mobile screenshot added.

## Suggested GitHub Commits
- `Part 2: add external CSS stylesheet`
- `Part 2: improve desktop layout`
- `Part 2: add responsive tablet and mobile styles`
- `Part 2: add mobile navigation`
- `Part 2: update README changelog`

## References
- MDN Web Docs — CSS: https://developer.mozilla.org/en-US/docs/Web/CSS
- MDN Web Docs — CSS Grid: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs — Flexbox: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs — Responsive Design: https://developer.mozilla.org/en-US/docs/Learn_web_development/Core/CSS_layout/Responsive_Design
- W3C — CSS: https://www.w3.org/Style/CSS/
- IIE Web Development prescribed learning material
